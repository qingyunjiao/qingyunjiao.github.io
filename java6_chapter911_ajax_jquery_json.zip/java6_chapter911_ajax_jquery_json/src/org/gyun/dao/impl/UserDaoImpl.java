package org.gyun.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.gyun.dao.BaseDao;
import org.gyun.dao.UserDao;
import org.gyun.enity.User;

/**
 * 
 * @ClassName��UserDaoImpl.java
 * @Description���û�Daoʵ����
 * @Author��DongGaoYun
 * @URL�� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @QQ��1050968899
 * @WeiXin��QingYunJiao
 * @Date��2019-8-19 ����
 * @Version��1.0
 */
public class UserDaoImpl extends BaseDao implements UserDao {
	// ��ʼ��
	private Logger logger = Logger.getLogger(UserDaoImpl.class);
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;

	private String quers = "query success";
	private String querf = "query fail";
	private String ups = "update success";
	private String upf = "update fail";

	@Override
	public int add(User user) {
		// SQL
		String sql = "insert into user(uname,upass,ufile,uremark) values(?,?,?,?)";
		Object[] params = { user.getUname(), user.getUpass(), user.getUfile(),
				user.getUremark() };
		return this.executeUpdate(sql, params);
	}

	@Override
	public List<User> getUser(Integer currentPage, Integer pageSize) {
		// sql
		String sql = "SELECT id,uname,upass,ufile,uremark FROM USER WHERE 1=1 LIMIT ?,?";
		Object[] params = { currentPage, pageSize };

		rs = this.executeQuery(sql, params);
		User user = null;
		List<User> userList = new ArrayList<User>();
		try {
			while (rs.next()) {
				user = new User();
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String password = rs.getString(3);
				String ufile = rs.getString(4);
				String uremark = rs.getString(5);
				user.setId(id);
				user.setUname(name);
				user.setUpass(password);
				user.setUfile(ufile);
				user.setUremark(uremark);
				userList.add(user);

			}
			logger.info(quers);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(querf);
		} finally {
			closeAll(con, ps, rs);
		}
		return userList;
	}

	@Override
	public int getUserByCount() {
		// sql
		String sql = "SELECT COUNT(1) FROM USER";
		Object[] params = {};
		// ���ò�ѯ����
		rs = this.executeQuery(sql, params);
		int num = 0;
		try {
			while (rs.next()) {
				num = rs.getInt(1);
				System.out.println(num);
			}
			logger.info(quers);
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(querf);
		} finally {
			closeAll(con, ps, rs);
		}
		return num;
	}

	@Override
	public int del(int id) {
		// sql
		String sql = "DELETE FROM USER WHERE id=?;";
		Object[] params = { id };
		// ���ò�ѯ����
		return this.executeUpdate(sql, params);
	}

	/* (non-Javadoc)
	 * @see org.gyun.dao.UserDao#getUserByUnameAndUpass(org.gyun.enity.User)
	 */
	@Override
	public User getUserByUnameAndUpass(User users) {
		// sql
		String sql = "SELECT id,uname,upass,ufile,uremark FROM USER WHERE uname=? and upass=?";
		Object[] params = { users.getUname(), users.getUpass() };

		rs = this.executeQuery(sql, params);
		User user = null;
		// List<User> userList = new ArrayList<User>();
		try {
			while (rs.next()) {
				user = new User();
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String password = rs.getString(3);
				String ufile = rs.getString(4);
				String uremark = rs.getString(5);
				user.setId(id);
				user.setUname(name);
				user.setUpass(password);
				user.setUfile(ufile);
				user.setUremark(uremark);
				// userList.add(user);
				System.out.println("getUserByUnameAndUpass-------------->"
						+ user.getUname() + user.getUpass());

			}
			logger.info(quers);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(querf);
		} finally {
			closeAll(con, ps, rs);
		}
		return user;
	}

	/*
	 * ��ѯ�����û���Ϣ
	 */
	@Override
	public List<User> getUserAll() {
		// sql
		String sql = "SELECT ID,UNAME,UPASS FROM USER";
		Object[] params = {};

		rs = this.executeQuery(sql, params);
		User user = null;
		List<User> userList = new ArrayList<User>();
		try {
			while (rs.next()) {
				user = new User();
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String password = rs.getString(3);
				user.setId(id);
				user.setUname(name);
				user.setUpass(password);
				userList.add(user);
			}
			logger.info(quers);
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(querf);
		} finally {
			closeAll(con, ps, rs);
		}
		return userList;
	}

}
