/**
 * 
 */
package com.javaxyz.test.string;

/**
 * @ClassName��StringTest.java
 * @Description��String�����equals�Ƚ�
 * @Author��DongGaoYun 
 * @URL��www.javaxyz.com ��   www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @QQ��1050968899
 * @WeiXin��QingYunJiao
 * @WeiXinGongZhongHao: JavaForum
 * @Date��2019-9-26 ����4:54:20
 * @Version��1.0
 */
public class StringTest {
	//������
	public static void main(String[] args) {
		String s1=new String("abc");
		String s2=new String("abc");
		String s3=s1;
		String s4="abc";
		System.out.println(s1==s2); //f
		System.out.println(s1==s3); //t
		System.out.println(s1==s4); //f
		System.out.println(s1.equals(s2));//f
		System.out.println(s1.equals(s3));//t
		System.out.println(s1.equals(s4));//t		
	}
}
