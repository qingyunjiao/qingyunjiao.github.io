package com.javaxyz.entity;

import java.util.Date;
import java.util.List;

/**
 * @ClassName��User.java
 * @Description��Userʵ����
 * @Author��DongGaoYun 
 * @URL�� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @QQ��1050968899
 * @WeiXin��QingYunJiao
 * @Date��2019-9-10 ����10:24:59
 * @Version��1.0
 */
public class User {
	private Integer id; //id 
	private String userCode; //�û�����
	private String userName; //�û�����
	private String userPassword; //�û�����
	private Integer gender;  //�Ա�
	private Date birthday;  //��������
	private String phone;   //�绰
	private String address; //��ַ
	private Integer userRole;    //�û���ɫ
	private Integer createdBy;   //������
	private Date creationDate; //����ʱ��
	private Integer modifyBy;     //������
	private Date modifyDate;   //����ʱ��
	
	private Integer age;//����
	
	private String userRoleName;    //�û���ɫ����
	
	
	public String getUserRoleName() {
		return userRoleName;
	}
	public void setUserRoleName(String userRoleName) {
		this.userRoleName = userRoleName;
	}
	public Integer getAge() {
		/*long time = System.currentTimeMillis()-birthday.getTime();
		Integer age = Long.valueOf(time/365/24/60/60/1000).IntegerValue();*/
		Date date = new Date();
		Integer age = date.getYear()-birthday.getYear();
		return age;
	}
	//Role����
	private Role role;
	//��ַ�ļ���
	List<Address> listAdd; //д����ʱ��ȫд�꣬���������޴���
	
	
	
	/**
	 * @return the listAdd
	 */
	public List<Address> getListAdd() {
		return listAdd;
	}
	/**
	 * @param listAdd the listAdd to set
	 */
	public void setListAdd(List<Address> listAdd) {
		this.listAdd = listAdd;
	}
	/**
	 * @return the role
	 */
	public Role getRole() {
		return role;
	}
	/**
	 * @param role the role to set
	 */
	public void setRole(Role role) {
		this.role = role;
	}
	/**
	 * @param age the age to set
	 */
	public void setAge(Integer age) {
		this.age = age;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public Integer getGender() {
		return gender;
	}
	public void setGender(Integer gender) {
		this.gender = gender;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Integer getUserRole() {
		return userRole;
	}
	public void setUserRole(Integer userRole) {
		this.userRole = userRole;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public Integer getModifyBy() {
		return modifyBy;
	}
	public void setModifyBy(Integer modifyBy) {
		this.modifyBy = modifyBy;
	}
	public Date getModifyDate() {
		return modifyDate;
	}
	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}
}
