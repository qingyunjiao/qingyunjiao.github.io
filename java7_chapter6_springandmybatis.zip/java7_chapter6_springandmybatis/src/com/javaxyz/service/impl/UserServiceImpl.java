/**
 * @Author��DongGaoYun
 * @Description:
 * @Date 2019-9-24������12:04:57
 * @Version 1.0
 * @Company: www.springhome.org
 */
package com.javaxyz.service.impl;

import java.util.List;

import com.javaxyz.entity.User;
import com.javaxyz.mapper.UserMapper;
import com.javaxyz.service.UserService;

/**
 * @ClassName��UserService.java
 * @Description��������Ϣ
 * @Author��DongGaoYun
 * @URL��www.javaxyz.com �� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @QQ��1050968899
 * @WeiXin��QingYunJiao
 * @WeiXinGongZhongHao: JavaForum
 * @Date��2019-9-27 ����12:04:57
 * @Version��1.0
 */
public class UserServiceImpl implements UserService {
	// ע��ӿڡ�UserDao
	private UserMapper userMapper;

	/**
	 * ��ȡ
	 */
	public UserMapper getUserMapper() {
		return userMapper;
	}

	/**
	 * setע��
	 */
	public void setUserMapper(UserMapper userMapper) {
		this.userMapper = userMapper;
	}

	@Override
	public int saveUser(User user) {
		// �����û���Ϣ
		return userMapper.addUser(user);
	}
	
	@Override
	public List<User> getUserByUserRoleChinaResultMap(User user) {
		return userMapper.getUserByUserRoleChinaResultMap(user);
	}
}
