/**
 * @Author��DongGaoYun
 * @Description:
 * @Date 2019-9-11������3:18:19
 * @Version 1.0
 * @Company: www.springhome.org
 */
package com.javaxyz.mapper.impl;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.log4j.Logger;
import org.mybatis.spring.SqlSessionTemplate;

import com.javaxyz.entity.User;
import com.javaxyz.mapper.UserMapper;
import com.javaxyz.util.MybatisUtil;

/**
 * @ClassName��UserMapperImpl.java
 * @Description��������Ϣ
 * @Author��DongGaoYun
 * @URL�� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @QQ��1050968899
 * @WeiXin��QingYunJiao
 * @Date��2019-9-11 ����3:18:19
 * @Version��1.0
 */

public class UserMapperImpl implements UserMapper {
	private static Logger logger = Logger.getLogger(UserMapperImpl.class);
	/*
	 * private SqlSession session; private InputStream in;
	 */
	private SqlSessionTemplate sqlSession;

	/**
	 * @return the sqlSession
	 */
	public SqlSessionTemplate getSqlSession() {
		return sqlSession;
	}

	/**
	 * @param sqlSession
	 *            the sqlSession to set
	 */
	public void setSqlSession(SqlSessionTemplate sqlSession) {
		this.sqlSession = sqlSession;
	}

	@Override
	public List<User> getUserByUserRoleChinaResultMap(User user) {
		// session.selectList("org.gyun.dao.UserMapper.getUserByUserNameAndUserRole");
		return sqlSession.getMapper(UserMapper.class)
				.getUserByUserRoleChinaResultMap(user);
	}

	@Override
	public int addUser(User user) {
		// 2. ���ýӿ�ӳ���Ӧ�ķ���
		return sqlSession.getMapper(UserMapper.class).addUser(user);
	}

}
