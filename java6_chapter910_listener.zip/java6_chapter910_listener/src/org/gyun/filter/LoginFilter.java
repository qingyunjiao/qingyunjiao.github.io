package org.gyun.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.gyun.enity.User;

/**
 * 
 * @ClassName��UserServlet3.java
 * @Description���ڶ��֡��̳�javax.servlet.GenericServlet��
 *                  ����Servlet��ͨ�ð汾����һ����Э���޹ص�Servlet
 * @Author��DongGaoYun
 * @URL�� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @QQ��1050968899
 * @WeiXin��QingYunJiao
 * @Date��2019-8-12 ����
 * @Version��1.0
 */
public class LoginFilter implements Filter {
	public LoginFilter(){
		System.out.println("LoginFilter-------���غ�ʵ����-------->");
	}
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		System.out.println("LoginFilter-------Filter��ʼ��------init->");

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		System.out.println("LoginFilter-------���˴���------doFilter-start->");
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		User user = (User) req.getSession().getAttribute("user");
		if (null == user) {
			System.out
					.println("LoginFilter-------���˴���------doFilter--if(null == user)--end->");
			request.getRequestDispatcher("login.jsp")
					.forward(request, response);
		} else {
			chain.doFilter(request, response);
			System.out
					.println("LoginFilter-------���˴���--doFilter--else--chain.doFilter-end->");
		}
	}

	@Override
	public void destroy() {
		System.out.println("LoginFilter-------Filter����------destroy->");

	}

}
