package org.gyun.enity;

import java.util.Date;



/**
 * 
 * @ClassName��User.java
 * @Description���û�ʵ����
 * @Author��DongGaoYun 
 * @URL�� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @QQ��1050968899
 * @WeiXin��QingYunJiao
 * @Date��2019-8-26 ����
 * @Version��1.0
 * 
 */
public class User{
	private int id; //���
	private String uname; //����
	private String upass; //����
	private String ufile; //�ϴ��ļ�
	private String uremark; //��ע��˵��
	private Date createtime; //����ʱ��
	
	
	
	
	/**
	 * @return the createtime
	 */
	public Date getCreatetime() {
		return createtime;
	}
	/**
	 * @param createtime the createtime to set
	 */
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpass() {
		return upass;
	}
	public void setUpass(String upass) {
		this.upass = upass;
	}
	public String getUfile() {
		return ufile;
	}
	public void setUfile(String ufile) {
		this.ufile = ufile;
	}
	public String getUremark() {
		return uremark;
	}
	public void setUremark(String uremark) {
		this.uremark = uremark;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", uname=" + uname + ", upass=" + upass
				+ ", ufile=" + ufile + ", uremark=" + uremark + "]";
	}
}
