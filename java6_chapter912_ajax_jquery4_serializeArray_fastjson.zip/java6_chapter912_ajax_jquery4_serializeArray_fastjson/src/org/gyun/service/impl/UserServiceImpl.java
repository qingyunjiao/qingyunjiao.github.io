package org.gyun.service.impl;

import java.util.List;

import org.gyun.dao.UserDao;
import org.gyun.dao.impl.UserDaoImpl;
import org.gyun.enity.User;
import org.gyun.service.UserService;

/**
 * 
 * @ClassName��UserServiceImpl.java
 * @Description���û���ҵ��ʵ����
 * @Author��DongGaoYun
 * @URL�� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @QQ��1050968899
 * @WeiXin��QingYunJiao
 * @Date��2019-8-26 ����
 * @Version��1.0
 */
public class UserServiceImpl implements UserService {
	UserDao dao;

	public UserServiceImpl() {
		dao = new UserDaoImpl();
	}

	@Override
	public int save(User user) {
		return dao.add(user);
	}

	@Override
	public User getUserByUnameAndUpass(User user) {
		System.out.println("UserServiceImpl------>"+dao);
		return dao.getUserByUnameAndUpass(user);
	}

	@Override
	public List<User> getUserAll() {
		return dao.getUserAll();
	}

}
