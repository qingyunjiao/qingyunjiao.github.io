$(function() {
	$("#uname").blur(function() {
		// 获取页面文本框name="unamen"的属性值
		var $uname = $(this).val();
		// 判断$uname是否为空
		if (null == $uname || '' == $uname) {// 根据判断,在相关页面上显示相应的提示信息
			$(this).next().html("用户名不能为空!");
		} else {
			//第三种方式实现ajax异步刷新--post
			$.post("userServlet1", {// 要发送到服务器的数据
				uname : $uname
			}, function(data) {// 入参表示响应结果
				// 根据判断,在相关页面上显示相应的提示信息
				if (data == 'true') {
					$("#uname").next().html("用户名不能用2!");
				} else {
					$("#uname").next().html("恭喜你!用户名可以用2!");
				}
			}, "text");
			
			
			//第二种方式实现ajax异步刷新--get
/*			$.get("userServlet1", {// 要发送到服务器的数据
				uname : $uname
			}, function(data) {// 入参表示响应结果
				// 根据判断,在相关页面上显示相应的提示信息
				if (data == 'true') {
					$("#uname").next().html("用户名不能用1!");
				} else {
					$("#uname").next().html("恭喜你!用户名可以用1!");
					
				}
			}, "text");
*/			
			
			//第一种方式实现ajax异步刷新--ajax
			/*
			 * // 使用jquery发送Ajax请求 $.ajax({ url : "userServlet1",// 提交的URL路径
			 * method : "get",// 发送请求的方式 data : {// 要发送到服务器的数据 uname : $uname },
			 * dataType : "text",// 指定返回的数据形式 // 响应成功时的回调函数 success :
			 * function(data) {// 入参表示响应结果 // 根据判断,在相关页面上显示相应的提示信息 if (data ==
			 * 'true') { $("#uname").next().html("用户名不能用!"); } else {
			 * $("#uname").next().html("恭喜你!用户名可以用!");
			 *  } }
			 *  })
			 */
		}
	})
});