$(function() {
	// 第五种 使用jquery发送Ajax请求 html
	$.get("userServlet", {// 要发送到服务器的数据
		method : "ajaxhtml"
	}, function(data) {// 入参表示响应结果
		var $data = $(data);
		$data.each(function() {
			$("#div>table").html(data);
			$("tr:even").css("background", "gray");
		});
	}, "html");
});
