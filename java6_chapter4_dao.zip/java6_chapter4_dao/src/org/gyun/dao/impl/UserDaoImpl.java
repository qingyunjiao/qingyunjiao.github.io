package org.gyun.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.gyun.dao.BaseDao;
import org.gyun.dao.UserDao;
import org.gyun.entity.User;
/**
 * 
 * @ClassName��UserDaoImpl.java
 * @Description��User�ӿ�ʵ����
 * @Author��DongGaoYun 
 * @URL�� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @Date��2019-7-31 ����11:16:38
 * @Version��1.0
 */
public class UserDaoImpl extends BaseDao implements UserDao {
	// ��ʼ��
	private Logger logger = Logger.getLogger(UserDaoImpl.class);
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	
	private String quers = "query success";
	private String querf = "query fail";
	private String ups = "update success";
	private String upf = "update fail";
	@Override
	public List<User> getUser() {
		//sql
		String sql="SELECT ID,NAME,PASSWORD,EMAIL FROM USER";
		rs=this.executeQuery(sql, null);
		User user=null;
		List<User> userList=new ArrayList<User>();
		try {
			while(rs.next()){
				user=new User();
				int id=rs.getInt(1);
				String name=rs.getString(2);
				String password=rs.getString(3);
				String email=rs.getString(4);
				user.setId(id);
				user.setName(name);
				user.setPassword(password);
				user.setEmail(email);
				userList.add(user);
				
			}
			logger.info(quers);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(querf);
		}finally{
			closeAll(con, ps, rs);
		}
		return userList;
	}

	@Override
	public int add(int id, String name, String upass, String email) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int addUser(User user) {
		String sql="insert into user(id,name,password,email) value(?,?,?,?)";
		Object[] params={user.getId(),user.getName(),user.getPassword(),user.getEmail()};
		int num=this.executeUpdate(sql, params);
		if(num>0){
			logger.info(ups);
		}else
			logger.error(upf);
		return num;
	}

}
