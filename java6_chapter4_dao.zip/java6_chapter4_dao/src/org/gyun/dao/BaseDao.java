package org.gyun.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.gyun.util.ConfigManager;

/**
 * 
 * @ClassName��BaseDao.java
 * @Description�����ࣨ�����ࣩ
 * @Author��DongGaoYun
 * @URL�� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @Date��2019-7-31 ����10:08:11
 * @Version��1.0
 */
@SuppressWarnings("static-access")
public class BaseDao {
	// ��ʼ��
	private Logger logger = Logger.getLogger(BaseDao.class); //��־
	private Connection con;
	private PreparedStatement ps;//Ԥ�������
	private ResultSet rs;//���������
	
	//�ڶ��������ļ��ķ�����k-v
	String url=ConfigManager.getInstance().getProperty("url");
	private String user =ConfigManager.getInstance().getProperty("user");
	private String password =ConfigManager.getInstance().getProperty("password");
	
	//��һ�����÷�ʽ
/*	private String url = "jdbc:mysql:///p19";
	private String user = "root";
	private String password = "aaa";
*/	
	//��ʾ��־��Ϣ
	private String drs = "driver success";
	private String drf = "driver fail";
	private String cons = "connection success";
	private String conf = "connection fail";
	private String quers = "query success";
	private String querf = "query fail";
	private String ups = "update success";
	private String upf = "update fail";

	// 2.��������
	public Connection getConnection() {
		// ����
		try {
			Class.forName("com.mysql.jdbc.Driver");
			logger.info(drs);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			logger.error(drf);
		}
		// ����
		try {
			con = DriverManager.getConnection(url, user, password);
			logger.info(cons);
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(conf);
		}
		return con;
	}

	// 3.��ѯ ResultSet
	/*
	 * id name 1 params[i] id 2 params[i] name
	 */
	public ResultSet executeQuery(String sql, Object... params) {
		// ����
		try {
			//PreparedStatement����
			ps = getConnection().prepareStatement(sql);
			if (null != params && params.length > 0) {
				for (int i = 0; i < params.length; i++) {
					ps.setObject(i + 1, params[i]);
				}
			}
			//��ѯ
			rs = ps.executeQuery();
			logger.info(quers);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(querf);
		}finally{
			closeAll(null, null, null);
		}
		return rs;
	}

	// 4.��ɾ��
	public int executeUpdate(String sql, Object... params) {
		// ����
		int num = 0;
		try {
			ps = getConnection().prepareStatement(sql);
			if (null != params && params.length > 0) {
				for (int i = 0; i < params.length; i++) {
					ps.setObject(i + 1, params[i]);
				}
			}
			num = ps.executeUpdate();
			logger.info(ups);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(upf);
		}finally{
			closeAll(null, ps, null);
		}
		return num;
	}
	// 5.�ر���Դ
	public void closeAll(Connection con,PreparedStatement ps,ResultSet rs){
		try {
			if (rs != null&&!rs.isClosed())
				rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			if (ps != null&&!ps.isClosed())
				ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			if (con != null&&!con.isClosed())
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
