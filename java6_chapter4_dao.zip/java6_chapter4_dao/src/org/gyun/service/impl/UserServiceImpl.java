package org.gyun.service.impl;

public class UserServiceImpl {

}
