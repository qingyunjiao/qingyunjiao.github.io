package org.gyun.test;

import static org.junit.Assert.*;

import java.util.List;

import org.gyun.dao.UserDao;
import org.gyun.dao.impl.UserDaoImpl;
import org.gyun.enity.User;
import org.gyun.service.UserService;
import org.gyun.service.impl.UserServiceImpl;
import org.gyun.util.Page;
import org.junit.Test;

/**
 * 
 * @ClassName��UserTest.java
 * @Description��������
 * @Author��DongGaoYun 
 * @URL�� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @QQ��1050968899
 * @WeiXin��QingYunJiao
 * @Date��2019-8-9 ����
 * @Version��1.0
 */
public class UserTest {

	@Test
	public void test() {
		UserDao dao = new UserDaoImpl(); 
		User user=new User();
		user.setUname("������");
		user.setUpass("110");
		user.setUfile("hxq.png");
		user.setUremark("����һ����!ʲô��û��д");
		int num = dao.add(user);
		if (num > 0) {
			System.out.println("���ӳɹ�!");
		} else {
			System.out.println("����ʧ��!");
		}
	}

	@Test
	public void page() {
		UserDao dao = new UserDaoImpl();
		List<User> userlist = dao.getUser(1, 6);
		for (User user : userlist) {
			System.out.println(user);
		}
	}

	@Test
	public void getUserByCount() {
		UserDao dao = new UserDaoImpl();
		int num = dao.getUserByCount();
		System.out.println(num);
	}

	@Test
	public void getUserByPage() {
		UserService service = new UserServiceImpl();
		Page page = service.getUserByPage(1, 2);
		System.out.println(page.getTotalPage() + "-" + page.getTotalCount());
	}
	/**
	 * ����idɾ������
	 */
	@Test
	public void getDel() {
		UserService service = new UserServiceImpl();
		int num= service.del(4);
		System.out.println(num);
	}
	

}
