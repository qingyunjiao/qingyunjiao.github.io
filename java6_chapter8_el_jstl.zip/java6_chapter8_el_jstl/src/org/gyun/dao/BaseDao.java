package org.gyun.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.gyun.util.ConfigManager;


/**
 * 
 * @ClassName��BaseDao.java
 * @Description��dao����
 * @Author��DongGaoYun 
 * @URL�� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @QQ��1050968899
 * @WeiXin��QingYunJiao
 * @Date��2019-8-5 ����2:53:22
 * @Version��1.0
 */
public class BaseDao {
	// ��ʼ������
	private Logger logger = Logger.getLogger(BaseDao.class);
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	String url = ConfigManager.getConfigManager().getProperties("url");
	String user = ConfigManager.getConfigManager().getProperties("user");
	String password =ConfigManager.getConfigManager().getProperties("password");

	// 1.��������
	public Connection getConnection(){
		//��������
		try {
			Class.forName(ConfigManager.getConfigManager().getProperties("driver"));
			logger.info("�����ɹ�!");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			logger.info("����ʧ��!");
		}
		try {
			con = DriverManager.getConnection(url, user, password);
			logger.info("���ӳɹ�!");
		} catch (SQLException e) {
			e.printStackTrace();
			logger.info("����ʧ��!");
		}
		return con;
		
	}
	// 2.��ѯ
	public ResultSet executeQuery(String sql,Object...params){
		try {
			ps=getConnection().prepareStatement(sql);
			if(params!=null&&params.length>0){
				for (int i = 0; i < params.length; i++) {
					ps.setObject(i+1, params[i]);
				}
			}
			rs=ps.executeQuery();
			logger.info("��ѯ�ɹ�!");
		} catch (SQLException e) {
			e.printStackTrace();
			logger.info("��ѯʧ��!");
		}finally{
			closeAll(null, null, null);
		}
		return rs;
	}
	// 3.��ɾ��
	public int executeUpdate(String sql,Object...params){
		int num=0;
		try {
			ps=getConnection().prepareStatement(sql);
			if(params!=null&&params.length>0){
				for (int i = 0; i < params.length; i++) {
					ps.setObject(i+1, params[i]);
				}
			}
			 num=ps.executeUpdate();
			 logger.info("���³ɹ�!");
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error("����ʧ��!");
		}finally{
			closeAll(null, ps, null);
		}
		return num;
	}
	// 4.�ر���Դ
	public void closeAll(Connection con,PreparedStatement ps,ResultSet rs){
		try {
			if(rs!=null&&!rs.isClosed()){
				rs.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			if(ps!=null&&!ps.isClosed()){
				ps.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			if(con!=null&&!con.isClosed()){
				con.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
