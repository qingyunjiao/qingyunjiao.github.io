package org.gyun.util;

import java.util.List;

import org.gyun.enity.User;

/**
 * 
 * @ClassName��Page.java
 * @Description����ҳ����
 * @Author��DongGaoYun
 * @URL�� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @QQ��1050968899
 * @WeiXin��QingYunJiao
 * @Date��2019-8-7 ����9:58:15
 * @Version��1.0
 */
public class Page {
	// ��ǰҳ�桡
	private Integer currentPage = 1;
	// ÿҳ������2��
	private Integer pageSize = 2;
	// ��ѯ��������
	private Integer totalCount = 0;
	// ��ҳ������
	private Integer totalPage = 0;
	// ҳ���ܼ���
	private List<User> UserList;

	@Override
	public String toString() {
		return "Page [currentPage=" + currentPage + ", pageSize=" + pageSize
				+ ", totalCount=" + totalCount + ", totalPage=" + totalPage
				+ ", UserList=" + UserList + "]";
	}

	public List<User> getUserList() {
		return UserList;
	}

	public void setUserList(List<User> userList) {
		UserList = userList;
	}

	public Integer getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		if (totalCount > 0) {
			this.totalCount = totalCount;
			//ͨ���õ���������,��ȡ��ҳ��
			this.totalPage = this.totalCount % this.pageSize == 0 ? this.totalCount
					/ this.pageSize
					: this.totalCount / this.pageSize + 1;
		} else {
			this.totalCount = 0;
		}
	}

	public Integer getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(Integer totalPage) {
		this.totalPage = totalPage;
	}

}
