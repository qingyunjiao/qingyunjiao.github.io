package org.gyun.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.gyun.dao.BaseDao;
import org.gyun.dao.UserDao;
import org.gyun.enity.User;
import org.gyun.util.Page;

public class UserDaoImpl extends BaseDao implements UserDao {
	// ��ʼ��
	private Logger logger = Logger.getLogger(UserDaoImpl.class);
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;

	private String quers = "query success";
	private String querf = "query fail";
	private String ups = "update success";
	private String upf = "update fail";

	@Override
	public int add(User user) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<User> getUser(Integer currentPage, Integer pageSize) {
		// sql
		String sql = "SELECT id,uname,upass,ufile,uremark FROM USER WHERE 1=1 LIMIT ?,?";
		Object[] params = { currentPage, pageSize };
		rs = this.executeQuery(sql, params);
		User user = null;
		List<User> userList = new ArrayList<User>();
		try {
			while (rs.next()) {
				user = new User();
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String password = rs.getString(3);
				String ufile = rs.getString(4);
				String uremark = rs.getString(5);
				user.setId(id);
				user.setUname(name);
				user.setUpass(password);
				user.setUfile(ufile);
				user.setUremark(uremark);
				userList.add(user);

			}
			logger.info(quers);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(querf);
		} finally {
			closeAll(con, ps, rs);
		}
		return userList;
	}

	@Override
	public int getUserByCount() {
		// sql
		String sql = "SELECT COUNT(1) FROM USER";
		Object[] params = {};
		// ���ò�ѯ����
		rs = this.executeQuery(sql, params);
		int num = 0;
		try {
			while (rs.next()) {
				num = rs.getInt(1);
				System.out.println(num);
			}
			logger.info(quers);
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(querf);
		} finally {
			closeAll(con, ps, rs);
		}
		return num;
	}

}
