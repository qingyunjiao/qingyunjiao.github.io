package org.gyun.test;

import static org.junit.Assert.*;

import java.util.List;

import org.gyun.dao.BaseDao;
import org.gyun.dao.impl.UserDaoImpl;
import org.gyun.entity.User;
import org.gyun.util.ConfigManager;
import org.junit.Test;
/**
 * ����(���²������,�Ѿ�����)
 * @ClassName��UserTest.java
 * @Author��DongGaoYun 
 * @URL�� www.gyun.org��www.gaoyun.net
 * @Email��DongGaoYun@qq.com
 * @Date��2019-8-2 ����12:24:43
 * @Version��1.0
 */
public class UserTest {
	//��Ԫ����
	@Test
	public void test() {
		BaseDao dao=new BaseDao();
		//connection����jndiʱҪ����!
		//dao.getConnection();
		UserDaoImpl impl=new UserDaoImpl();
/*		List<User> userList=impl.getUser();
		for (User user : userList) {
			System.out.println(user.getId()+user.getName());
		}*/
		User user=new User();
		user.setId(444);
		user.setName("xxx");
		user.setPassword("666");
		user.setEmail("666@168.com");
		impl.addUser(user);
	}
	@Test
	public void test2() {
		//ConfigManager c=new ConfigManager();
		String url=ConfigManager.getInstance().getProperty("url");
		System.out.println(url);
	}

}
