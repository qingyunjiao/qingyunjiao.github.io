package org.gyun.service.impl;

import java.util.List;

import org.gyun.dao.UserDao;
import org.gyun.dao.impl.UserDaoImpl;
import org.gyun.entity.User;
import org.gyun.service.UserService;

/**
 * 
 * @ClassName��UserServiceImpl.java
 * @Description���û�ʵ����
 * @Author��DongGaoYun 
 * @URL�� www.gyun.org��www.gaoyun.net
 * @Email��DongGaoYun@qq.com
 * @Date��2019-8-2 ����11:07:14
 * @Version��1.0
 */
public class UserServiceImpl implements UserService{
	private UserDao dao=new UserDaoImpl();
	@Override
	public List<User> getUser() {
		return dao.getUser();
	}

}
