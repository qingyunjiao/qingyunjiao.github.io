/**
 * @Author��DongGaoYun
 * @Description:
 * @Date 2019-9-20������3:23:14
 * @Version 1.0
 * @Company: www.springhome.org
 */
package com.javaxyz.test;

import static org.junit.Assert.*;

import org.apache.taglibs.standard.lang.jstl.test.beans.Factory;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.javaxyz.entity.Dog;
import com.javaxyz.factorys.Factorys;
import com.javaxyz.interfaces.Pet;
import com.javaxyz.springioc.HelloWorld;

/**
 * @ClassName��FactoryTest.java
 * @Description��������Ϣ
 * @Author��DongGaoYun
 * @URL�� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @QQ��1050968899
 * @WeiXin��QingYunJiao
 * @Date��2019-9-20 ����3:23:14
 * @Version��1.0
 */
@SuppressWarnings("all")
public class FactoryTest {

	@Test
	public void test2() {
		// ��ȡ�����ļ�
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		HelloWorld hello = (HelloWorld) context.getBean("hello");
		hello.print();
	}

	@Test
	public void test1() {
		// ��������
		Factorys factory = new Factorys();
		Pet pet = null;
		// pet = factory.getPet("dog");
		pet = factory.getPet("cat");
		// ���÷���
		pet.getEat();
		pet.getSport();
	}

}
