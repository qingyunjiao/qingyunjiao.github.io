/**
 * @Author��DongGaoYun
 * @Description:
 * @Date 2019-9-24������11:33:56
 * @Version 1.0
 * @Company: www.springhome.org
 */
package com.javaxyz.entity;

import java.io.Serializable;

/**
 * @ClassName��User.java
 * @Description���û���Ϣ��
 * @Author��DongGaoYun 
 * @URL��www.javaxyz.com ��   www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @QQ��1050968899
 * @WeiXin��QingYunJiao
 * @WeiXinGongZhongHao: JavaForum
 * @Date��2019-9-24 ����11:33:56
 * @Version��1.0
 */
public class User implements Serializable {
	//����
	private Integer id;
	private String uName;
	private String uPass;
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the uName
	 */
	public String getuName() {
		return uName;
	}
	/**
	 * @param uName the uName to set
	 */
	public void setuName(String uName) {
		this.uName = uName;
	}
	/**
	 * @return the uPass
	 */
	public String getuPass() {
		return uPass;
	}
	/**
	 * @param uPass the uPass to set
	 */
	public void setuPass(String uPass) {
		this.uPass = uPass;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", uName=" + uName + ", uPass=" + uPass + "]";
	}
	
	
}
