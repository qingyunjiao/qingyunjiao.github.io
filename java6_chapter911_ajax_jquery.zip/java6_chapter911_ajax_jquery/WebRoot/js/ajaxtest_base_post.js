$(function() {
	$("#uname").blur(
			function() {
				// 获取页面文本框name="unamen"的属性值
				var $uname = $(this).val();
				// 判断$uname是否为空
				if (null == $uname || '' == $uname) {// 根据判断,在相关页面上显示相应的提示信息
					$(this).next().html("用户名不能为空!");
				} else {
					// ajax原生出马
					// 1.创建对象:XMLHttpRequest
					var xhr = createXmlHttpRequest();
					// 2.设置请求信息
					var url = "userServlet";
					xhr.open("post", url);
					// post的请求头
					xhr.setRequestHeader("Content-Type",
							"application/x-www-form-urlencoded");
					// 3.设置回调信息
					xhr.onreadystatechange = callback;
					// 4.发送请求
					xhr.send("uname=" + $uname);// 需要发送的数据信息,$uname为用户名文本框获取的值
					// 在回调函数callback中处理服务器响应的关键代码
					function callback() {
						if (xhr.readyState == 4 && xhr.status == 200) {
							// 以文本形式获取响应值
							var data = xhr.responseText;
							// 根据判断,在相关页面上显示相应的提示信息
							if (data == 'true') {
								$("#uname").next().html("用户名不能用!");
							} else {
								$("#uname").next().html("恭喜你!用户名可以用!");

							}
						}
					}
				}
			})
});
// 返回兼容的对象XMLHttpRequest
function createXmlHttpRequest() {
	// 兼容IE6及其它浏览器
	if (window.XMLHttpRequest) {
		return new XMLHttpRequest();
	} else {
		// 兼容IE6或IE6以下浏览器
		return new ActiveXObject("Microsoft.XMLHTTP");
	}
}