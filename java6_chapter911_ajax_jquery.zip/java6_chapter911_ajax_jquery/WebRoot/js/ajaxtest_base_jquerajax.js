$(function() {
	$("#uname").blur(function() {
		// 获取页面文本框name="unamen"的属性值
		var $uname = $(this).val();
		// 判断$uname是否为空

		if (null == $uname || '' == $uname) {// 根据判断,在相关页面上显示相应的提示信息
			$(this).next().html("用户名不能为空!");
		} else {
			// 使用jquery发送Ajax请求
			$.ajax({
				url : "userServlet",// 提交的URL路径
				method : "get",// 发送请求的方式
				data : {// 要发送到服务器的数据
					uname : $uname
				},
				dataType : "text",// 指定返回的数据形式
				// 响应成功时的回调函数
				success : function(data) {// 入参表示响应结果
					// 根据判断,在相关页面上显示相应的提示信息
					if (data == 'true') {
						$("#uname").next().html("用户名不能用!");
					} else {
						$("#uname").next().html("恭喜你!用户名可以用!");

					}
				}

			})

		}
	})
});

function createXmlHttpRequest() {
	// 兼容IE6及其它浏览器
	if (window.XMLHttpRequest) {
		return new XMLHttpRequest();
	} else {
		// 兼容IE6以下浏览器
		return new ActiveXObject("Microsoft.XMLHTTP");
	}
}