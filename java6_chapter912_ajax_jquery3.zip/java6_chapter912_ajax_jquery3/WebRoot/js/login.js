$(function() {
	$("#submit").click(
			function() {
				// 获取页面文本框name="unamen"的属性值
				var $uname = $("#uname").val();
				var $upass = $("#upass").val();
				var $method = $("#method").val();
				$("#uname").next().html("");
				$("#upass").next().html("");

				// 判断$uname是否为空
				if (null == $uname || '' == $uname) {// 根据判断,在相关页面上显示相应的提示信息
					$("#uname").next().html("用户名不能为空!");
					return false;
				} else if (null == $upass || '' == $upass) {// 根据判断,在相关页面上显示相应的提示信息
					$("#upass").next().html("密码不能为空!");
					return false;
				} else {
					// 第四种 使用jquery发送Ajax请求 --getJSON
					$.getJSON("userServlet", {// 要发送到服务器的数据
						uname : $uname,
						method : $method,
						upass : $upass
					}, function(data) {// 入参表示响应结果
						// alert(data);
						if (data == '1') {
							alert("用户名不能为空");
						} else if (data == '2') {
							alert("密码不能为空");
						} else if (data == '3') {
							alert("用户名或密码不正确1");
						} else {
							var $data = $(data);
							// 根据判断,在相关页面上显示相应的提示信息
							$data.each(function() {
								var tr = "<tr><td>" + this.id + "</td><td>"
										+ this.uname + "</td><td>" + this.upass
										+ "</td></tr>";

								$("#div2>table").append(tr);
							});
							$("#div1").css("display", "none");
							$("#div2").css("display", "block");
							$("tr:even").css("background", "gray");
						}
					});

					// 第一种 使用jquery发送Ajax请求 ajax
					/*
					 * $.ajax({ url : "userServlet",// 提交的URL路径 method :
					 * "get",// 发送请求的方式 data : {// 要发送到服务器的数据 uname :
					 * $uname,method:$method,upass:$upass }, dataType :
					 * "json",// 指定返回的数据形式 // 响应成功时的回调函数 success :
					 * function(data) {// 入参表示响应结果 //alert(data); if(data=='1'){
					 * alert("用户名不能为空"); }else if(data=='2'){ alert("密码不能为空");
					 * }else if(data=='3'){ alert("用户名或密码不正确"); }else{ var
					 * $data=$(data); // 根据判断,在相关页面上显示相应的提示信息
					 * $data.each(function() { var tr = "<tr><td>" + this.id + "</td><td>" +
					 * this.uname + "</td><td>" + this.upass + "</td></tr>";
					 * 
					 * $("#div2>table").append(tr); });
					 * $("#div1").css("display","none");
					 * $("#div2").css("display","block");
					 * $("tr:even").css("background", "gray"); } } });
					 */
				}
			});
});
