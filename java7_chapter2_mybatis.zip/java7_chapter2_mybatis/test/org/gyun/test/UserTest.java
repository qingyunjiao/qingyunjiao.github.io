package org.gyun.test;

import java.io.IOException;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.gyun.enity.User;
import org.gyun.service.UserService;
import org.gyun.service.impl.UserServiceImpl;
import org.junit.Test;

/**
 * 
 * @ClassName��UserTest.java
 * @Description��������
 * @Author��DongGaoYun
 * @URL�� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @QQ��1050968899
 * @WeiXin��QingYunJiao
 * @Date��2019-9-11 
 * @Version��1.0
 */
public class UserTest {
	SqlSession session;
	InputStream in;
	/*
	 * ���������ͽ�ɫȥ��ѯ�û���Ϣ2
	 */
	@Test
	public void test5() {
		UserService service=new UserServiceImpl();
		User user=new User();
		user.setUserName("��");
		user.setUserRole(2);
		List<User> userl = service.getUserByUserRoleChinaResultMap(user);
		for (User user1 : userl) {
			System.out.println(user1.getUserName()+" ��"+user1.getUserRoleName());
		}
	}
	/*
	 * ���������ͽ�ɫȥ��ѯ�û���Ϣ1
	 */
	@Test
	public void test4() {
		UserService service=new UserServiceImpl();
		User user=new User();
		user.setUserName("��");
		user.setUserRole(2);
		List<User> userl = service.getUserByUserRoleChina(user);
		for (User user1 : userl) {
			System.out.println(user1.getUserName()+" ��"+user1.getUserRoleName());
		}
	}
	/*
	 * ���������ͽ�ɫȥ��ѯ�û���Ϣ
	 */
	@Test
	public void test3() {
		UserService service=new UserServiceImpl();
		Map<String, String> map=new HashMap<String, String>();
		map.put("u", "��");
		map.put("r", "2");
		List<User> userl = service.getUserByUserNameAndUserRole(map);
		for (User user : userl) {
			System.out.println(user.getUserName());
		}
	}
	/*
	 * ��ѯ�����û�
	 */
	@Test
	public void test2() {
		UserService service=new UserServiceImpl();
		List<User> userl = service.getAllUser();
			for (User user : userl) {
				System.out.println(user.getUserName());
			}
		}
	/*
	 * ��ѯ�����û�
	 */
	@Test
	public void test() {
		
		// ���������ļ�
		String resource = "config-mybatis.xml";
		// ��ȡ�����ļ�
		try {
			in = Resources.getResourceAsStream(resource);
			// ����SqlSession����
			SqlSessionFactory factory = new SqlSessionFactoryBuilder()
					.build(in);
			session = factory.openSession();
			// ����xml�ļ�
			List<User> userl = session
					.selectList("org.gyun.dao.UserMapper.getAllUser");
			for (User user : userl) {
				System.out.println(user.getUserName());
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			session.close();
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/*
	 * @Test public void test() { UserDao dao=new UserDaoImpl(); User user=new
	 * User(); user.setUname("������"); user.setUpass("110");
	 * user.setUfile("hxq.png"); user.setUremark("����һ����!ʲô��û��д"); int
	 * num=dao.add(user); if(num>0){ System.out.println("���ӳɹ�!"); }else{
	 * System.out.println("����ʧ��!"); } }
	 */
}
