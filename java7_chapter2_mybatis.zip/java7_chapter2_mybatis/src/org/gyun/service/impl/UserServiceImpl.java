/**
 * @Author��DongGaoYun
 * @Description:
 * @Date 2019-9-11������3:20:33
 * @Version 1.0
 * @Company: www.springhome.org
 */
package org.gyun.service.impl;

import java.util.List;
import java.util.Map;

import org.gyun.dao.UserMapper;
import org.gyun.dao.impl.UserMapperImpl;
import org.gyun.enity.User;
import org.gyun.service.UserService;

/**
 * @ClassName��UserServiceImpl.java
 * @Description��������Ϣ
 * @Author��DongGaoYun
 * @URL�� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @QQ��1050968899
 * @WeiXin��QingYunJiao
 * @Date��2019-9-11 ����3:20:33
 * @Version��1.0
 */
public class UserServiceImpl implements UserService {
	//���ýӿ�
	UserMapper userMapper;
	
	public UserServiceImpl() {
		userMapper = new UserMapperImpl();
	}

	@Override
	public List<User> getAllUser() {
		// TODO Auto-generated method stub

		return userMapper.getAllUser();
	}

	@Override
	public List<User> getUserByUserNameAndUserRole(Map<String, String> maps) {
		return userMapper.getUserByUserNameAndUserRole(maps);
	}

	@Override
	public List<User> getUserByUserRoleChina(User user) {
		return userMapper.getUserByUserRoleChina(user);
	}
	@Override
	public List<User> getUserByUserRoleChinaResultMap(User user) {
		return userMapper.getUserByUserRoleChinaResultMap(user);
	}

}
