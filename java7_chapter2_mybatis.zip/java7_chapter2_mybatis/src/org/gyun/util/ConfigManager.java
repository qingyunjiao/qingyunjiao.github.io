package org.gyun.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


/**
 * @ClassName��ConfigManager.java
 * @Description����ȡ�����ļ�������
 * @Author��DongGaoYun 
 * @URL�� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @Date��2019-8-26 ����
 * @Version��1.0
 */

public class ConfigManager {
	// ��ʼ������
	private static ConfigManager configManager;
	private Properties properties;
	
	private ConfigManager() {
		properties=new Properties();
		InputStream in=ConfigManager.class.getResourceAsStream("/database.properties");
//		InputStream in=ConfigManager.class.getClassLoader().getResourceAsStream("database.properties");
		try {
			properties.load(in);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
		}
		
	}
	
	public static synchronized ConfigManager getConfigManager(){
		if(configManager==null){
			configManager=new ConfigManager();
		}
		return configManager;
	}
	
	public String getProperties(String key){
		return properties.getProperty(key);
	}


}
