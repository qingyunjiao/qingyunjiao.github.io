/**
 * @Author��DongGaoYun
 * @Description:
 * @Date 2019-9-11������3:18:19
 * @Version 1.0
 * @Company: www.springhome.org
 */
package org.gyun.dao.impl;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.gyun.dao.UserMapper;
import org.gyun.enity.User;

/**
 * @ClassName��UserMapperImpl.java
 * @Description��������Ϣ
 * @Author��DongGaoYun
 * @URL�� www.gyun.org
 * @Email��DongGaoYun@qq.com
 * @QQ��1050968899
 * @WeiXin��QingYunJiao
 * @Date��2019-9-11 ����3:18:19
 * @Version��1.0
 */

public class UserMapperImpl implements UserMapper {
	SqlSession session;
	InputStream in;

	@Override
	public List<User> getAllUser() {
		List<User> userl = new ArrayList<User>();
		// ���������ļ�
		String resource = "config-mybatis.xml";
		// ��ȡ�����ļ�
		try {
			in = Resources.getResourceAsStream(resource);
			// ����SqlSession����
			SqlSessionFactory factory = new SqlSessionFactoryBuilder()
					.build(in);
			session = factory.openSession();
			// ����xml�ļ�
			userl = session.selectList("org.gyun.dao.UserMapper.getAllUser");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			session.close();
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return userl;

	}

	/* (non-Javadoc)
	 * @see org.gyun.dao.UserMapper#getUserByUserNameAndUserRole()
	 */
	@Override
	public List<User> getUserByUserNameAndUserRole(Map<String, String> maps){
		List<User> userl = new ArrayList<User>();
		// ���������ļ�
		String resource = "config-mybatis.xml";
		// ��ȡ�����ļ�
		try {
			in = Resources.getResourceAsStream(resource);
			// ����SqlSession����
			SqlSessionFactory factory = new SqlSessionFactoryBuilder()
					.build(in);
			session = factory.openSession();

			// ����xml�ļ�
//			userl = session.selectList("org.gyun.dao.UserMapper.getUserByUserNameAndUserRole");
			userl =session.getMapper(UserMapper.class).getUserByUserNameAndUserRole(maps);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			session.close();
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return userl;
	}

	/* (non-Javadoc)
	 * @see org.gyun.dao.UserMapper#getUserByUserRoleChina(org.gyun.enity.User)
	 */
	@Override
	public List<User> getUserByUserRoleChina(User user) {
		List<User> userl = new ArrayList<User>();
		// ���������ļ�
		String resource = "config-mybatis.xml";
		// ��ȡ�����ļ�
		try {
			in = Resources.getResourceAsStream(resource);
			// ����SqlSession����
			SqlSessionFactory factory = new SqlSessionFactoryBuilder()
					.build(in);
			session = factory.openSession();

			// ����xml�ļ�
//			userl = session.selectList("org.gyun.dao.UserMapper.getUserByUserNameAndUserRole");
			userl =session.getMapper(UserMapper.class).getUserByUserRoleChina(user);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			session.close();
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return userl;
	}
	@Override
	public List<User> getUserByUserRoleChinaResultMap(User user) {
		List<User> userl = new ArrayList<User>();
		// ���������ļ�
		String resource = "config-mybatis.xml";
		// ��ȡ�����ļ�
		try {
			in = Resources.getResourceAsStream(resource);
			// ����SqlSession����
			SqlSessionFactory factory = new SqlSessionFactoryBuilder()
			.build(in);
			session = factory.openSession();
			
			// ��������xml�ļ� 
//			userl = session.selectList("org.gyun.dao.UserMapper.getUserByUserNameAndUserRole");
			userl =session.getMapper(UserMapper.class).getUserByUserRoleChinaResultMap(user);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			session.close();
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return userl;
	}
}
